
Comment of the extension owner:
===============================

This extension contains:

Italian spelling dictionaries | Version: 2012-04-04
---------------------------------------------------
* For more details of the dictionary version read the relevant readme files.
	
* Even though having built and published the dictionary extension, the extension 
  owner has no responsibility for maintaining related Italian dictionaries. 
* For contacting the authors of Italian dictionaries, please read their related 
  README files.
  
* Available separate download:
  http://extensions.services.openoffice.org/en/project/dict-it

Latin spelling dictionaries | Version: 2013-03-28
-------------------------------------------------
* In a test of an available dedicated Latin hyphenation module, problems appeared 
  in compliance with compound words. It seemed therefore better to use the Italian 
  hyphenation module renamed to "hyph_la.dic". Of course, I know that the rules for 
  Italian and Latin hyphenation are not (quiet) the same.
  Prefering an original Latin hyphenation dictionary for LibreOffice or OpenOffice.org, 
  feel free to use it. Copy the corresponding module in the hyph_la folder. Make sure 
  that the alternative module has the same name as the supplied module and that it is 
  encoded as Unix UTF-8.

* The Latin spelling dictionary 3.1 has been considerably improved. For detailed 
  information read the readme files. Your comment is wellcome. Detecting errors or 
  missing words, please contact the author via e-mail.
  This extension is available as bundled version together with Italian dictionaries as 
  well as separate extension.
	
* For contacting the Author of Latin dictionary: karl<point>zeiler<at>t-online.de

* Available downloads:
  http://extensions.libreoffice.org/extension-center/latin-spelling-and-hyphenation-dictionaries
  http://extensions.libreoffice.org/extension-center/italian-and-latin-spelling-dictionaries
  http://extensions.services.openoffice.org/project/dict-la
  http://extensions.services.openoffice.org/project/dict-it-IT_and_Latin

For contacting the extension owner write to:
Karl Zeiler <karl(dot)zeiler(at)t-online.de>